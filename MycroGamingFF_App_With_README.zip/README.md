# Mycro Gaming FF - Contact Form App

This is a FastAPI-based contact form app with the following features:

- Collects name, email, message, and resume (PDF)
- Captcha validation (3 + 4)
- Sends confirmation email to user and notification to admin
- Stores submission data in SQLite (`contact.db`)
- Admin panel to view submissions at `/admin?key=secret123`

## Deployment (Render)

1. Upload this project to GitHub
2. Create a new Web Service on https://render.com
3. Set the **start command**:

```
uvicorn contact_form_app:app --host 0.0.0.0 --port 10000
```

4. Add required environment variables for SMTP if needed.

Enjoy!
